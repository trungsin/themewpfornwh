<?php 
/*******************************************/
## Custom widget list
/*******************************************/

require('widgets/recent-posts.php');
require('widgets/social-icons.php');
require('widgets/about-me.php');
?>